const titoli = ['Acus', 'Audix', 'Biasin', 'Dynaudio', 'Fender', 'Gibson','Ibanez', 'Presonus', 'Rode', 'Yamaha'];
const immagini = ['./img/acus.jpeg', './img/audix.jpeg', './img/biasin.jpeg', './img/dynaudio3.jpeg', './img/fender.jpeg', 
'./img/gibson.jpeg', './img/ibanez.jpeg', './img/presonus.jpeg', './img/rode1.jpeg', './img/yamaha.jpeg'];
const descrizioni = ['Location :Rome', 'Location: New York', 'Location: Paris', 'Location: Firenze',
'Location: Canberra','Location: Barcellona','Location: Bucarest','Location: London','Location: Berlin','Location: Mosca'];